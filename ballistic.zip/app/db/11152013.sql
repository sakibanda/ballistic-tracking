

ALTER TABLE `bt_s_variables`  DROP INDEX `var_value`;