<?php $this->menu();  ?>

<h1>Success Transaction</h1>
<p><?php echo $message; ?></p>