<?php $this->menu();  ?>

<h1>Failed Transaction</h1>
<p><?php echo $message; ?></p>