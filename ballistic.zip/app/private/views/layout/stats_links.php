<div class="grid_12" style="text-align: center;">
    <a href="/stats/">Campaign Stats</a> -
    <a href="/dateparting/">Week/Date Parting</a>
</div>