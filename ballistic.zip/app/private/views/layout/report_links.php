<div class="grid_12" style="text-align: center;">
    <a href="/reports/">Custom Data Report</a> -
    <a href="/reports/breakdown">Breakdown</a> -
    <a href="/platforms/mobile">Mobile Breakdown</a> -
    <a href="#">Subid Analysis Report</a>
</div>