<h1 class="grid_12"><span>Analyze IP Addresses</span></h1>                                                                                                                     

<?php
$this->setVar('page','/ajax/analyze/viewips');
$this->setVar('opts','analyze/ips');
$this->loadTemplate('report_options');
?>