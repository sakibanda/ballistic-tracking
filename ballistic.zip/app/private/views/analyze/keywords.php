<h1 class="grid_12"><span>Analyze Keywords</span></h1>

<?php
$this->setVar('page','/ajax/analyze/viewkeywords');
$this->setVar('opts','analyze/keywords');
$this->loadTemplate('report_options');
?>