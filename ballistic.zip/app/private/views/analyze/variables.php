<h1 class="grid_12"><span>Analyze Variables</span></h1>

<?php
$this->setVar('page','/ajax/analyze/viewvariables');
$this->setVar('opts','analyze/variables');
$this->loadTemplate('report_options');
?>