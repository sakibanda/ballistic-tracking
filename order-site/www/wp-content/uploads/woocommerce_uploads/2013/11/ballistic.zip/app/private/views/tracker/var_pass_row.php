<tr>
    <td>
        <div class="grid_8">
            <input type="text" name="variable_name[]" value="" />
        </div>
        <div class="grid_4 lp_var_pass_opts">
            <input type="hidden" name="variable_lp[]" value="0"/>
            <input type="checkbox" class="var_check" /><span>LP</span>
            <input type="hidden" name="variable_offer[]" value="0"/>
            <input type="checkbox" class="var_check" /><span>Offer</span>
        </div>
    </td>
    <td>
        <input type="text" name="variable_note[]" value="" />
    </td>
    <td>
        <img src="/theme/img/icons/16x16/delete.png" onclick="deleteVarPassTable(this);" style="cursor: pointer; width: 16px; height: 16px;">
    </td>
</tr>