<h1 class="grid_12"><span>Browser Breakdown</span></h1>


<?php
$this->setVar('page','/ajax/platforms/viewbrowser');
$this->setVar('opts','platforms/browser');
$this->loadTemplate('report_options');
?>