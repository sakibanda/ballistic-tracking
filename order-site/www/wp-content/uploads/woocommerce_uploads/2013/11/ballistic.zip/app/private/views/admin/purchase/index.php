<?php $this->menu();  ?>

<h1 class="grid_12"><span>Buy New Domain Access</span></h1>

<div class="grid_9">
    <form id="form_payment" action='/admin/purchase/buy' method='post'>
        <ul>
            <li>
                <button>Buy an API KEY</button>
                <h3>Advanced Redirects<br/>
                <span>$5,000/month</span></h3>
            </li>
        </ul>
    </form>
</div>