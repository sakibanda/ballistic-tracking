<h1 class="grid_12"><span>State Breakdown</span></h1>

<?php
$this->setVar('page','/ajax/geography/viewstates');
$this->setVar('opts','geography/states');
$this->loadTemplate('report_options');
?>