<h1 class="grid_12"><span>Campaign Overview</span></h1>

<?php
$this->setVar('page','/ajax/overview/viewOverview');
$this->setVar('opts','overview/overview');
$this->loadTemplate('report_options');
?>