<?php
//include ballistic.
require_once(__DIR__ . '/private/index.php');