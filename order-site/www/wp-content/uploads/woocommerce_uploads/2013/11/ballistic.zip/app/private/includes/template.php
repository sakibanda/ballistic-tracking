<?php
function template_top($title = 'Ballistic Tracking') {
	require_once(BT_ROOT . '/private/views/layout/protected_header.php');
} 
	
function template_bottom() { 
	require_once(BT_ROOT . '/private/views/layout/protected_footer.php');
}
