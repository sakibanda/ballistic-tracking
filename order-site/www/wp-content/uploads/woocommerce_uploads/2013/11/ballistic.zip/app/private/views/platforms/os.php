<h1 class="grid_12"><span>OS Breakdown</span></h1>

<?php
$this->setVar('page','/ajax/platforms/viewos');
$this->setVar('opts','platforms/os');
$this->loadTemplate('report_options');
?>