				<div class="grid_12" style="text-align: right;">
					Ballistic Tracking <?php echo BT_VERSION; ?>
				</div>
				
				<div class="clear"></div>
			</div>
		</div>
	</body>
</html>