<h1 class="grid_12"><span>Analyze Referers</span></h1>

<?php
$this->setVar('page','/ajax/analyze/viewreferers');
$this->setVar('opts','analyze/referers');
$this->loadTemplate('report_options');
?>