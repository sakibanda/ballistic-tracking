<div class="box">
	<div class="header">
		<h2>Error 404</h2>
	</div>
	
	<div class="content">
		<p>The page you have requested could not be found</p>
	</div>
</div>