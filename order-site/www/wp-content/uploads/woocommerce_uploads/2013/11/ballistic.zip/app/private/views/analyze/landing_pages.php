<h1 class="grid_12"><span>Analyze Landing Pages</span></h1>
                                    

<?php
$this->setVar('page','/ajax/analyze/viewlps');
$this->setVar('opts','analyze/landing_page');
$this->loadTemplate('report_options');
?>